import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicioApiBebidas } from '../servicios/servicio-api-bebidas';
import { crearInformacionBebida, InformacionBebida } from '../entidades/informacion-bebida';

@Component({
  selector: 'app-menu-bebida',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './menu-bebida.html',
  styleUrl: './menu-bebida.css'
})
export class MenuBebida implements OnInit {

  bebidas = signal<any[]>([]);
  precios = signal<{ [id: string]: number }>({});
  cargando = signal<boolean>(false);
  cargandoInformacion = signal<boolean>(false);
  error = signal<string>('');
  informacionSeleccionada = signal<InformacionBebida | null>(null);
   categoriaSeleccionada = signal<string>('todas');

  constructor(private api: ServicioApiBebidas) {}

   ngOnInit(): void {
    this.cargarTodas();
  }

  cargarTodas(): void {
    this.categoriaSeleccionada.set('todas');
    this.cargando.set(true);
    this.error.set('');
    this.bebidas.set([]); // Limpia la lista anterior

    this.api.obtenerMenuCompletoBebidas().subscribe({
      next: (listaBebidas: any[]) => {
        this.bebidas.set(listaBebidas);
        this.asignarPrecios();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se pudo cargar el menú completo.');
      }
    });
  }

  cargarPorCategoriaB(categoria: string): void {
    this.categoriaSeleccionada.set(categoria);
    this.cargando.set(true);
    this.error.set('');
    this.bebidas.set([]); // Limpia la lista anterior

    this.api.bebidaPorCategoria(categoria).subscribe({
      next: (res: any) => {
       const lista = res.drinks ?? [];
        this.bebidas.set(lista);
        this.asignarPrecios();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.error.set(`No se pudieron cargar los platos de ${categoria}.`);
      }
    });
  }

  cargarPorTipoB(tipo: string): void {
    this.categoriaSeleccionada.set(tipo);
    this.cargando.set(true);
    this.error.set('');
    this.bebidas.set([]);

    this.api.bebidaPorTipo(tipo).subscribe({
      next: (res: any) => {
        const lista = res.drinks ?? [];
        this.bebidas.set(lista);
        this.asignarPrecios();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.error.set(`No se pudieron cargar las bebidas de tipo ${tipo}.`);
      }
    });
  }

  cargarTodoElMenu(): void {
    this.cargando.set(true);
    this.error.set('');

    // Llama al método del servicio que une las categorías de bebidas
    this.api.obtenerMenuCompletoBebidas().subscribe({
      next: (listaBebidas: any[]) => {
        this.bebidas.set(listaBebidas);
        this.asignarPrecios();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se pudo cargar las bebidas.');
      }
    });
  }

  private asignarPrecios(): void {
    const preciosActuales = { ...this.precios() };

    for (const bebida of this.bebidas()) {
      const id = bebida.idDrink;

      if (!preciosActuales[id]) {
        preciosActuales[id] = this.api.asignarPrecioAleatorio();
      }

      if (!bebida.strDrinkThumb && id) {
        bebida.strDrinkThumb = `https://www.thecocktaildb.com/images/media/drink/${id}.jpg`;
      }
    }

    this.precios.set(preciosActuales);
  }

  agregarAlPedido(bebida: any): void {
    const item = {
      id: bebida.idDrink,
      tipo: 'bebida',
      nombre: bebida.strDrink,
      imagen: bebida.strDrinkThumb,
      precio: this.precios()[bebida.idDrink],
      cantidad: 1
    };
    console.log('Bebida agregada al pedido:', item);
  }

  mostrarInformacion(bebida: any): void {
    this.cargandoInformacion.set(true);
    this.informacionSeleccionada.set(
      crearInformacionBebida(bebida, this.precios()[bebida.idDrink])
    );

    this.api.obtenerDetalleBebida(bebida.idDrink).subscribe({
      next: (respuesta: any) => {
        const bebidaCompleta = respuesta.drinks?.[0] ?? bebida;
        this.informacionSeleccionada.set(
          crearInformacionBebida(
            bebidaCompleta,
            this.precios()[bebida.idDrink]
          )
        );
        this.cargandoInformacion.set(false);
      },
      error: () => {
        this.informacionSeleccionada.set(
          crearInformacionBebida(bebida, this.precios()[bebida.idDrink])
        );
        this.cargandoInformacion.set(false);
      }
    });
  }

  cerrarInformacion(): void {
    this.informacionSeleccionada.set(null);
  }

  buscarDesdePadre(tipo: string, texto: string): void {
    if (!texto.trim()) {
      this.cargarTodas();
      return;
    }

    this.categoriaSeleccionada.set('');
    this.cargando.set(true);
    this.error.set('');
    this.bebidas.set([]);

    const peticion =
      tipo === 'nombre'
        ? this.api.buscarPorNombre(texto)
        : this.api.buscarPorIngrediente(texto);

    peticion.subscribe({
      next: (respuesta: any) => {
        const lista = respuesta.drinks ?? [];
        this.bebidas.set(lista);
        this.asignarPrecios();
        this.cargando.set(false);

        if (lista.length === 0) {
          this.error.set('No se encontraron bebidas con esa búsqueda.');
        }
      },
      error: () => {
        this.cargando.set(false);
        this.error.set('Ocurrió un error al realizar la búsqueda.');
      }
    });
  }
}
